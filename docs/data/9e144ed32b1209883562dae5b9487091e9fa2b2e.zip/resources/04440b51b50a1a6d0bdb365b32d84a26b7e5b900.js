const observer = new MutationObserver((mutationsList) => {
    for (const mutation of mutationsList) {
        mutation.addedNodes.forEach((node) => {
            if (node.nodeType === 1 && node.classList.contains('uiModal')) {
                const target = node.querySelector('.maica-modal_animated');
                if (target) {
                    setTimeout(() => {
                        target.classList.add('maica-modal_run-animation');
                    }, 500);
                }

                // Add swipe to close functionality for mobile
                initSwipeToClose(node);
            }
            if (node.nodeType === 1 && node.classList.contains('errorsList')) {

            }
        });

        mutation.removedNodes.forEach((node) => {
            if (node.nodeType === 1 && node.classList.contains('uiModal')) {
            }
        });
    }
});

observer.observe(document.body, { childList: true, subtree: true });

// Swipe to close modal functionality
function initSwipeToClose(modal) {
    // Only enable on mobile devices
    if (window.innerWidth > 480) return;

    const swipeableElements = modal.querySelectorAll('.modal-body, .slds-modal__content, .container');

    swipeableElements.forEach(element => {
        let touchStartX = 0;
        let touchStartY = 0;
        let touchStartTime = 0;
        let isSwipeActive = false;

        element.addEventListener('touchstart', function(e) {
            const touch = e.touches[0];
            touchStartX = touch.clientX;
            touchStartY = touch.clientY;
            touchStartTime = Date.now();
            isSwipeActive = false;
        }, { passive: true });

        element.addEventListener('touchmove', function(e) {
            const touch = e.touches[0];
            const deltaX = touch.clientX - touchStartX;
            const deltaY = Math.abs(touch.clientY - touchStartY);

            // Check if this is more of a horizontal swipe from the left edge
            if (touchStartX < 50 && deltaX > 30 && deltaY < 100) {
                if (!isSwipeActive) {
                    isSwipeActive = true;
                    modal.classList.add('swipe-active');
                }

                // Provide visual feedback during swipe
                const progress = Math.min(deltaX / 150, 1);
                if (progress > 0.1) {
                    element.style.transform = `translateX(${deltaX * 0.3}px)`;
                    element.style.opacity = 1 - (progress * 0.3);

                    // Apply same effects to next action buttons
                    const nextActionButtons = modal.querySelectorAll('.maica-button_next-action, .maica-section_next-action');
                    nextActionButtons.forEach(button => {
                        button.style.transform = `translateX(${deltaX * 0.3}px)`;
                        button.style.opacity = 1 - (progress * 0.5); // Slightly more fade for buttons
                    });
                }

                // Prevent default scrolling when swiping horizontally
                e.preventDefault();
            }
        }, { passive: false });

        element.addEventListener('touchend', function(e) {
            const touch = e.changedTouches[0];
            const deltaX = touch.clientX - touchStartX;
            const deltaY = Math.abs(touch.clientY - touchStartY);
            const deltaTime = Date.now() - touchStartTime;

            // Reset visual feedback
            modal.classList.remove('swipe-active');
            element.style.transform = '';
            element.style.opacity = '';

            // Reset next action buttons styles
            const nextActionButtons = modal.querySelectorAll('.maica-button_next-action, .maica-section_next-action');
            nextActionButtons.forEach(button => {
                button.style.transform = '';
                button.style.opacity = '';
            });

            // Check if swipe should trigger close
            if (touchStartX < 50) { // Started from left edge
                const screenWidth = window.innerWidth;
                const swipeProgress = deltaX / screenWidth;
                const isLongSwipe = deltaX > screenWidth * 0.7; // Swiped 70% of screen width
                const isStandardSwipe = deltaX > 100 && deltaTime < 500; // Standard quick swipe
                const isMediumSwipe = deltaX > 150 && deltaTime < 1000; // Medium distance with more time
                const isSlowButFarSwipe = deltaX > 200 && deltaTime < 2000; // Slow but far swipe

                const isValidSwipe = (
                    isLongSwipe || // Always trigger if swiped far enough
                    isStandardSwipe || // Quick short swipe
                    isMediumSwipe || // Medium swipe
                    isSlowButFarSwipe // Slow but far swipe
                ) && deltaY < 100; // Still more horizontal than vertical

                if (isValidSwipe) {
                    // Add success animation
                    modal.classList.add('swipe-success');

                    // Find and trigger the cancel/close action
                    setTimeout(() => {
                        triggerModalClose(modal);
                    }, 100);
                }
            }
        }, { passive: true });
    });
}

// Function to trigger modal close
function triggerModalClose(modal) {
    try {
        // Look for various ways to close the modal

        // 1. Try to find back button or toolbar back action
        const backButton = modal.querySelector('[onback], .maica-button_back button, c-lwc-toolbar button[onclick*="back"]');
        if (backButton) {
            backButton.click();
            return;
        }

        // 2. Try to find cancel button
        const cancelButton = modal.querySelector('button[name="Cancel"], .cancel-button');
        if (cancelButton) {
            cancelButton.click();
            return;
        }

        // 3. Try to find close button
        const closeButton = modal.querySelector('.slds-modal__close, .modal-close, [data-dismiss="modal"]');
        if (closeButton) {
            closeButton.click();
            return;
        }

        // 4. Try to trigger Aura component events
        const auraComponent = modal.querySelector('[data-aura-class]');
        if (auraComponent && window.$A) {
            try {
                const cmp = window.$A.getComponent(auraComponent);
                if (cmp && cmp.cancelModal) {
                    cmp.cancelModal(false);
                    return;
                }
            } catch (e) {
                console.warn('Could not trigger Aura cancelModal:', e);
            }
        }

        // 5. Dispatch custom close event
        const closeEvent = new CustomEvent('modalSwipeClose', {
            bubbles: true,
            detail: { modal: modal }
        });
        modal.dispatchEvent(closeEvent);

        console.log('Swipe to close triggered - no standard close method found');

    } catch (error) {
        console.error('Error closing modal via swipe:', error);
    }
}
